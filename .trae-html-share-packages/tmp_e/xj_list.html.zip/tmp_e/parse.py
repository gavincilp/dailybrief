import re, sys, html, glob, os

files = sys.argv[1:] or sorted(glob.glob('/workspace/tmp_e/*.html'))

# match an anchor tag with href and inner text/title
anchor_re = re.compile(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.S | re.I)
titleattr_re = re.compile(r'title=["\']([^"\']+)["\']', re.I)
# date patterns
date_pats = [
    re.compile(r'20\d{2}-\d{1,2}-\d{1,2}'),
    re.compile(r'20\d{2}\.\d{1,2}\.\d{1,2}'),
    re.compile(r'20\d{2}/\d{1,2}/\d{1,2}'),
    re.compile(r'>\s*\d{1,2}-\d{1,2}\s*<'),
    re.compile(r'20\d{2}年\d{1,2}月\d{1,2}日'),
]

def clean(s):
    s = re.sub(r'<[^>]+>', '', s)
    s = html.unescape(s)
    return re.sub(r'\s+', ' ', s).strip()

for f in files:
    try:
        txt = open(f, encoding='utf-8', errors='ignore').read()
    except Exception as e:
        continue
    out = []
    for m in anchor_re.finditer(txt):
        href = m.group(1); inner = m.group(2)
        t = clean(inner)
        if len(t) < 6:
            ta = titleattr_re.search(m.group(0))
            if ta: t = clean(ta.group(1))
        # look for a date in the 200 chars after the anchor
        tail = txt[m.end():m.end()+300]
        dt = ''
        for p in date_pats:
            mm = p.search(tail)
            if mm:
                dt = clean(mm.group(0))
                break
        if not dt:
            # date before anchor within same li
            head = txt[max(0, m.start()-200):m.start()]
            for p in date_pats:
                mm = p.search(head)
                if mm:
                    dt = clean(mm.group(0)); break
        if t and re.search(r'[\u4e00-\u9fff]', t) and ('20' in dt or re.search(r'\d{1,2}-\d{1,2}', dt)):
            if re.search(r'\d{4,}/(t\d+|20\d{4})|t20\d{5}|/20\d{4}/', href) or href.endswith('.html') or href.endswith('.shtml'):
                out.append((dt, t, href))
    print("="*20, os.path.basename(f), "="*20)
    for dt, t, href in out:
        print(f"{dt}\t{t[:80]}\t{href}")