import re, sys, html
for f in sys.argv[1:]:
    t = open(f, encoding='utf-8', errors='ignore').read()
    # title
    mt = re.search(r'<title>(.*?)</title>', t, re.S)
    title = html.unescape(re.sub(r'\s+',' ',mt.group(1))).strip() if mt else ''
    # find body-ish: take text after removing scripts/styles
    body = re.sub(r'<(script|style)[^>]*>.*?</\1>', ' ', t, flags=re.S|re.I)
    body = re.sub(r'<[^>]+>', ' ', body)
    body = html.unescape(body)
    body = re.sub(r'[ \t\r\f\v]+', ' ', body)
    body = re.sub(r'\n+', '\n', body)
    body = re.sub(r'\n[ ]+', '\n', body)
    # collapse
    comp = re.sub(r'\s+', '', body)
    print("="*25, f, "="*25)
    print("TITLE:", title)
    # print condensed
    out = comp
    print(out[:1800])
    print()