# Agent D-武汉｜武汉市住房和城市更新局 逐期巡检记录

- 采集窗口：北京时间 2026-10-11 07:00 — 2026-10-12 07:00（周日为主，含周一凌晨）
- 固定信源：武汉市住房和城市更新局 zgj.wuhan.gov.cn（政府域名 .gov.cn）
- 巡检时间：2026-10-12
- 结论：**全栏目零新增**（窗口内 7 个固定栏目均无新增条目；各栏最新一条均早于窗口起点 2026-10-11 07:00）

---

## 一、窗口内新增条目

**无。全栏目零新增。**

窗口为周末（10-11 周日、10-12 周一凌晨），信源未发布落入该窗口的新内容。

---

## 二、各栏目最新一条（逐栏目巡检基准）

| # | 栏目 | 栏目URL | 最新一条标题 | 发布时间 | 原文链接 |
|---|------|---------|--------------|----------|----------|
| 1 | 政务动态—通知公告 | https://zgj.wuhan.gov.cn/zwdt/tzgg/ | 关于贯彻落实《关于完善商品住房销售制度的通知》的实施意见 | 2026-10-01 | https://zgj.wuhan.gov.cn/zwdt/tzgg/202609/t20260930_2856363.shtml |
| 2 | 政务动态—住更/监督动态 | https://zgj.wuhan.gov.cn/zwdt/jdxw/ | 武汉市市政工程2026年“质量月”观摩交流会成功举办 | 2026-10-08 | https://zgj.wuhan.gov.cn/zwdt/jdxw/202610/t20261008_2856911.shtml |
| 3 | 政府信息公开—规范性文件库 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/gfxwjsjk/ | 市住房和城市更新局关于印发武汉市住房和城市更新行政处罚裁量基准的通知 | 2026-09-24 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/gfxwjsjk/202609/t20260924_2853957.shtml |
| 4 | 政策解读 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/zcjd/ | [文字方式]《武汉市住房和城市更新行政处罚裁量基准》政策解读 | 2026-09-24 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/zcjd/202609/t20260924_2853958.shtml |
| 5 | 政策问答 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/zcwd/ | 一部城市更新法规，对普通市民有何利好？ | 2026-06-29 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/zcwd/202606/t20260629_2814150.shtml |
| 6 | 专题专栏—“五改四好”城市更新专题 | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/ | （入口为 JS 跳转壳→./zcwj_csgx/）见下方子栏 | — | — |
| 7 | 市政府门户专题「武汉住房和城市更新」 | https://3g.wuhan.gov.cn/ztzl/24zt/szfhcsgx | “先尝后买”免费试两个月，35年没交过物业费的老小区如今一签就是5年 | 2026-10-08 | https://3g.wuhan.gov.cn/ztzl/24zt/szfhcsgx/hygl/202610/t20261008_2857568.shtml |

### “五改四好”专题子栏（跟进 JS 跳转后的子栏目）

| 子栏 | 子栏URL | 最新一条标题 | 发布时间 | 原文链接 |
|------|---------|--------------|----------|----------|
| 政策文件 zcwj_csgx | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/zcwj_csgx/ | 关于印发支持城市更新的若干政策措施（第三批）的通知 | 2026-07-20 | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/zcwj_csgx/202607/t20260724_2824868.shtml |
| 工作动态 gzdt_csgx | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/gzdt_csgx/ | 张俊勇调研武汉市城市更新工作 | 2026-08-18 | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/gzdt_csgx/202608/t20260818_2835344.shtml |
| 五改四好 wgsh_csgx | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/wgsh_csgx/ | 武汉城市更新进行时｜青山区：老工业基地的“焕新密码” | 2026-04-08 | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/wgsh_csgx/202605/t20260518_2765883.shtml |

---

## 三、窗口内各栏最新日期核对（防遗漏）

| 栏目 | 页面内最新日期 | 是否存在 2026-10-11/10-12 条目 |
|------|----------------|-------------------------------|
| 通知公告 tzgg | 2026-10-01 | 无 |
| 住更动态 jdxw | 2026-10-08 | 无 |
| 规范性文件库 gfxwjsjk | 2026-09-24 | 无 |
| 政策解读 zcjd | 2026-09-24 | 无 |
| 政策问答 zcwd | 2026-06-29 | 无 |
| 五改四好·政策文件 | 2026-07-20 | 无 |
| 五改四好·工作动态 | 2026-08-18 | 无 |
| 五改四好·五改四好 | 2026-04-08 | 无 |
| 市政府门户专题 3g | 2026-10-08 | 无 |

---

## 四、专栏可达性（HTTP）结论

| 栏目 | URL | HTTP |
|------|-----|------|
| 通知公告 | https://zgj.wuhan.gov.cn/zwdt/tzgg/ | 200 |
| 住更/监督动态 | https://zgj.wuhan.gov.cn/zwdt/jdxw/ | 200 |
| 规范性文件库 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/gfxwjsjk/ | 200 |
| 政策解读 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/zcjd/ | 200 |
| 政策问答 | https://zgj.wuhan.gov.cn/xxgk/zcfgyjd_1/zcwd/ | 200 |
| “五改四好”专题入口 | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/ | 200（JS 跳转壳，需跟进子栏） |
| 五改四好·政策文件 | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/zcwj_csgx/ | 200 |
| 五改四好·工作动态 | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/gzdt_csgx/ | 200 |
| 五改四好·五改四好 | https://zgj.wuhan.gov.cn/ztzl/wgshcsgx/wgsh_csgx/ | 200 |
| 市政府门户专题 | https://3g.wuhan.gov.cn/ztzl/24zt/szfhcsgx | 200（-L 跟随 301） |

说明：所有栏目均经 HTTP 代理（http_proxy=http://127.0.0.1:18080）直连，列表页均加 `--compressed`；市政府门户专题按要求 `-L` 跟随跳转。7 个固定栏目全部可正常抓取，无空体、无异常。

---

## 五、剔除说明（自筛记录）

本窗口无新增条目，无需执行筛选。为备查，对栏目近期条目按排除项已作判断，典型应剔除项示例（非本窗口、仅留存判定口径）：
- 通知公告中“关于一元路历史文化街区…拆除…审批事项的公示”(2026-09-09)——**单体项目公示**类，剔除。
- 住更动态中“市住房和城市更新局组织开展高温天气慰问活动”(2026-08-24)——**一般性活动/会议新闻**，剔除。
- 各类“双随机、一公开”检查通告、职业技能大赛报名通知——**例行事务性公告**，剔除。
- 市政府门户专题 hygl 板块物业费/智慧小区故事稿——属**宣传报道**，非制度性文件，剔除（本窗口亦无新增）。

> 以上均为既有条目口径记录，均不属于本采集窗口，未计入上报清单。

---

*一切以官网实际发布为准；本文件日期与链接均取自官网列表页原文，标题与链接一致。*