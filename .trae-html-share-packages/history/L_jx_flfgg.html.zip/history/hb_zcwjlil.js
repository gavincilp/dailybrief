var dJson,allData;

// var allData = dJson.data;
var curData = [];

var pageTemp = {
    pageSize: 20,
    pageNum: 1,
    totalSize: 0,
    totalPage: 0,
    startPage: 1,
    endPage: 0
}
var strIndex, endIndex;






function htmlData() {
    var listHtml = '';
    strIndex = pageTemp.pageSize * (pageTemp.pageNum - 1);
    endIndex = (pageTemp.pageSize * pageTemp.pageNum) - 1;

    if (endIndex >= pageTemp.totalSize) {
        endIndex = pageTemp.totalSize - 1;
    }

    for (var i = strIndex; i <= endIndex; i++) {
        var date = formatDate(curData[i].DOCRELTIME, "yyyy-MM-dd");
        var id=i+1;
		var XGJD=curData[i].XGJD;
		if(XGJD==""){
   listHtml += "<li><a href="+ curData[i].URL +" title=\""+ replaceLabelBr(curData[i].FILENAME) +"\" target='_blank'>"+ beautySub(replaceLabelBr(curData[i].FILENAME),28) +"</a><span>"+ date + "</span></li>"
        }
        else{
            listHtml += "<li><a href="+ curData[i].URL +" title=\""+ replaceLabelBr(curData[i].FILENAME) +"\"  target='_blank'>"+ beautySub(replaceLabelBr(curData[i].FILENAME),28) +"</a><em><a href='"+ curData[i].XGJD +"' class='text-blue' target='_blank'>[相关解读]</a></em><span>"+ date + "</span></li>"
        }
        
    }
    if(pageTemp.totalSize==0){
		listHtml += '<li><span>抱歉，没有搜索到相关的信息</span></li>';
	}
    page();

    if (pageTemp.pageNum === 1) {
        $('#atFirst,#pre').addClass('disabled').off('click')
    } else {
        $('#atFirst,#pre').removeClass('disabled')
        $('#atFirst').click(function () {
            pageTemp.pageNum = 1;
            htmlData();
        })
        $('#pre').click(function () {
            pageTemp.pageNum--;
            htmlData();
        })
    }

    if (pageTemp.pageNum === pageTemp.totalPage) {
        $('#next,#atLast').addClass('disabled')
    } else {
        $('#next,#atLast').removeClass('disabled')
        $('#next').click(function () {
            pageTemp.pageNum++;
            htmlData();
        })
        $('#atLast').click(function () {
            pageTemp.pageNum = pageTemp.totalPage;
            htmlData();
        })
    }

    $('.strPage').each(function () {
        var cNum = parseInt($(this).text());
        if (cNum === pageTemp.pageNum) {
            $(this).addClass('current').siblings().removeClass(
                'current');
        }
    })

    $('#ulList').html(listHtml);
}

//标题查询
function seachtitle(cVal) {
    curData = [];
    for (var i = 0; i < allData.length; i++) {
        var FILENAME = allData[i].FILENAME;
        var n = FILENAME.indexOf(cVal);
        if (n != -1) {
            curData.push(allData[i]);
        }
    }
    pageTemp.totalSize = curData.length;
    pageTemp.totalPage = Math.ceil(pageTemp.totalSize / pageTemp.pageSize);
	pageTemp.pageNum = 1;
    htmlData();
}

//文号查询
function seachwh(cVal) {
    curData = [];
    for (var i = 0; i < allData.length; i++) {
       var FILENUM = allData[i].FILENUM;
        var n = FILENUM.indexOf(cVal);
       if (n != -1) {
            curData.push(allData[i]);
        }
   }
    pageTemp.totalSize = curData.length;
    pageTemp.totalPage = Math.ceil(pageTemp.totalSize / pageTemp.pageSize);
	pageTemp.pageNum = 1;
    htmlData();
}
//主题分类查询
function seachInfo(cVal) {
    curData = [];
    for (var i = 0; i < allData.length; i++) {
        var FILETYPE = allData[i].FILENUM;
        var n = FILETYPE.indexOf(cVal);
        if (n != -1) {
            curData.push(allData[i]);
        }
    }
    pageTemp.totalSize = curData.length;
    pageTemp.totalPage = Math.ceil(pageTemp.totalSize / pageTemp.pageSize);
	pageTemp.pageNum = 1;
    htmlData();
}
//主题分类查询
function seachInfo1(cVal) {
    curData = [];
    for (var i = 0; i < allData.length; i++) {
        var FILETYPE = allData[i].FILETYPE;
        var n = FILETYPE.indexOf(cVal);
        if (n != -1) {
            curData.push(allData[i]);
        }
    }
    pageTemp.totalSize = curData.length;
    pageTemp.totalPage = Math.ceil(pageTemp.totalSize / pageTemp.pageSize);
	pageTemp.pageNum = 1;
    htmlData();
}

function formatDate(date, fmt) {
    if (date) {
        let fullDate = new Date(date.replace(/-/g, '/'));

        let o = {
            "M+": fullDate.getMonth() + 1, // 月份
            "d+": fullDate.getDate(), // 日
            "H+": fullDate.getHours(), // 小时
            "m+": fullDate.getMinutes(), // 分
            "s+": fullDate.getSeconds(), // 秒
            "q+": Math.floor((fullDate.getMonth() + 3) / 3), // 季度
            "S": fullDate.getMilliseconds() // 毫秒
        };

        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (fullDate.getFullYear() + "").substr(4 - RegExp.$1
                .length));
        }

        for (let k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k])
                    .substr(("" + o[k])
                        .length)));
            }
        }
        return fmt;
    } else {
        return "";
    }
};

function page() {
    var pageList = '<a href="javascript:;" id="atFirst">首页</a><a href="javascript:;" id="pre">上一页</a>';

    if (pageTemp.totalPage == null || pageTemp.totalPage <= 1) {
        $('.pages').hide();
    } else {
        $('.pages').show();
    }
    pageTemp.endPage = pageTemp.totalPage < 5 ? pageTemp.totalPage : 5;
    if (pageTemp.totalPage > 5 && pageTemp.pageNum > 4) {
        pageTemp.endPage = pageTemp.pageNum + 3 > pageTemp.totalPage ? pageTemp.totalPage : pageTemp
            .pageNum + 3;
    }

    var x = pageTemp.endPage - pageTemp.startPage;
    if (x != 4) {
        pageTemp.startPage = pageTemp.endPage - 4;
    }
    if (pageTemp.endPage < 5) {
        pageTemp.startPage = 1;
    }

    for (var i = pageTemp.startPage; i <= pageTemp.endPage; i++) {
        pageList += "<a class='strPage'>" + i + "</a>"
    }

    pageList += '<a href="javascript:;" id="next">下一页</a><a href="javascript:;" id="atLast">末页</a>';

    $('.pages').html(pageList);
};

$(document).on('click', '.strPage', function () {
    var cVal = parseInt($(this).text());
    pageTemp.pageNum = cVal;
    htmlData();
})
$(document).on('click', '#seachBtn', function () {
   var name=$('.wj-xzlx option:selected') .val();
   if(name=="文件名称"){
	   var cVal = $('#textfield3').val();
   seachtitle(cVal);
   }else if(name=="关键字"){
	    var cVal = $('#textfield3').val();
   seachtitle(cVal);
   }
   else{
	    var cVal = $('#textfield3').val();
   seachwh(cVal);
   }
})
$('#textfield3').on('keypress', function (event) {
    if (event.keyCode === 13) {
        var cVal = $('#textfield3').val();
        seachtitle(cVal);
        return false
    }
});
function getAllData() {
    jQuery.support.cors = true;
    jQuery.ajaxSetup({
        xhr: function () {
            if (window.ActiveXObject) {
                return new window.ActiveXObject("Microsoft.XMLHTTP");
            } else {
                return new window.XMLHttpRequest();
            }
        }
    });
    $.ajax({
        url: "/zfxxgk/zc/gfxwj/zcwj.json",
        type: "GET",
        success: function (res) {
            console.log(res);
            dJson = res;
            allData = dJson.data;
			 //allData.sort((a,b) => {
            //return a.DOCRELTIME > b.DOCRELTIME ? -1 : 1;
        //})
            for (var i = 0; i < allData.length; i++) {
                    curData.push(allData[i]);
            }
            pageTemp.totalSize = curData.length;
            pageTemp.totalPage = Math.ceil(pageTemp.totalSize / pageTemp.pageSize);
            htmlData();
        }
    })
}

getAllData();

function beautySub(str, len) {
    if (str) {
        var reg = /[\u4e00-\u9fa5]/g,
            slice = str.substring(0, len),
            chineseCharNum = (~~(slice.match(reg) && slice.match(reg).length)),
            realen = slice.length * 2 - chineseCharNum;
        return str.substr(0, realen) + (realen < str.length ? "..." : "");
    } else {
        return "";
    }
}

/*
     * 替换<br>标签
     * @param {string} str - url地址
     */
function replaceLabelBr (str) {
    var regBrackets = /\<*(&amp;lt;)*br\/*(&amp;gt;)*\>*/g;

    if (str) {
        return str.replace(regBrackets, '');
    } else {
        return null;
    }
}