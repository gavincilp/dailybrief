# -*- coding: utf-8 -*-
import re, json, ssl, gzip, urllib.request, urllib.parse

BASE = "https://www.mohurd.gov.cn"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Encoding": "gzip"})
    with urllib.request.urlopen(req, timeout=40, context=ctx) as r:
        d = r.read()
        if r.headers.get("Content-Encoding") == "gzip":
            d = gzip.decompress(d)
        return d

cols = {
    "政策发布": "/zhengcefabu/index.html",
    "政策文件库": "/gongkai/zc/wjk/index.html",
    "部门规章": "/gongkai/zhengce/gzk/index.html",
    "行政规范性文件": "/gongkai/zc/xzgfxwjk/index.html",
    "标准公告": "/gongkai/fdzdgknr/bzgg/index.html",
    "政策解读": "/gongkai/fdzdgknr/zcjd/index.html",
    "征求意见": "/gongkai/fdzdgknr/zqyj/index.html",
    "领导动态": "/xinwen/jsyw/index.html",
    "建设要闻": "/xinwen/gzdt/index.html",
    "地方信息": "/xinwen/dfxx/index.html",
}

out = {}
for name, path in cols.items():
    try:
        html = fetch(BASE + path).decode("utf-8", "ignore")
    except Exception as e:
        out[name] = {"error": "index fetch: %s" % e}
        continue
    m = re.search(r"queryData=\"([^\"]+)\"", html)
    if not m:
        out[name] = {"error": "no queryData"}
        continue
    qd = json.loads(m.group(1).replace("'", '"'))
    qd["paramJson"] = json.dumps({"pageNo": 1, "pageSize": 60, "search": ""})
    api = BASE + "/api-gateway/jpaas-publish-server/front/page/build/unit?" + urllib.parse.urlencode(qd)
    try:
        raw = fetch(api).decode("utf-8", "ignore")
        data = json.loads(raw)
        inner = data.get("data", {}).get("html", "")
    except Exception as e:
        out[name] = {"error": "api: %s" % e, "params": qd}
        continue
    items = []
    # each li block
    for li in re.findall(r"<li[^>]*>(.*?)</li>", inner, re.S):
        a = re.search(r'href="([^"]+)"[^>]*title="([^"]*)"', li)
        if not a:
            a = re.search(r'href="([^"]+)"[^>]*>([^<]+)<', li)
        d = re.search(r'class="date-info">([^<]+)<', li)
        if a:
            items.append({"url": a.group(1), "title": a.group(2).strip(), "date": d.group(1).strip() if d else ""})
    out[name] = {"items": items, "count": len(items), "params": {k: qd[k] for k in ("tplSetId","pageType","tagId","pageId")}}

with open("/workspace/_work/cols.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

for name, v in out.items():
    print("=== %s ===" % name)
    if "error" in v:
        print("  ERROR:", v["error"])
        continue
    print("  count=%d pageId=%s tagId=%s" % (v["count"], v["params"]["pageId"], v["params"]["tagId"]))
    for it in v["items"][:15]:
        print("   [%s] %s -> %s" % (it["date"], it["title"][:45], it["url"]))
